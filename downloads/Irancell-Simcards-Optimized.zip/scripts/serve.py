#!/usr/bin/env python3
"""Serve the built site locally, including its precompressed static assets."""

from __future__ import annotations

import argparse
import functools
import mimetypes
import re
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit


ASSET_EXTENSIONS = {
    ".avif", ".css", ".gif", ".ico", ".jpeg", ".jpg", ".js", ".json",
    ".mjs", ".mp4", ".png", ".svg", ".ttf", ".webm", ".webp", ".woff", ".woff2",
}
ROOT_FILES = {"robots.txt", "sitemap.xml", "favicon.ico", "favicon.png", "favicon.svg"}
FINGERPRINT = re.compile(r"(?:^|[-.])[0-9a-f]{8,64}(?=[.-]|$)", re.IGNORECASE)
CONTENT_TYPES = {
    ".avif": "image/avif", ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
    ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8",
    ".webp": "image/webp", ".woff": "font/woff", ".woff2": "font/woff2",
    ".xml": "application/xml; charset=utf-8",
}


def accepts_gzip(header: str) -> bool:
    """Respect explicit gzip exclusions and RFC Accept-Encoding wildcards."""
    encodings: dict[str, float] = {}
    for item in header.split(","):
        parts = [part.strip() for part in item.split(";")]
        if not parts[0]:
            continue
        quality = 1.0
        for parameter in parts[1:]:
            key, separator, value = parameter.partition("=")
            if separator and key.strip().lower() == "q":
                try:
                    quality = float(value)
                except ValueError:
                    quality = 0.0
        encodings[parts[0].lower()] = quality if 0 <= quality <= 1 else 0.0
    return encodings.get("gzip", encodings.get("*", 0.0)) > 0


class SiteHandler(SimpleHTTPRequestHandler):
    """Expose built pages and assets; never source, tooling, or directories."""

    def list_directory(self, path):
        self.send_error(HTTPStatus.NOT_FOUND)
        return None

    def send_head(self):
        try:
            url_path = unquote(urlsplit(self.path).path, errors="strict")
        except (UnicodeError, ValueError):
            self.send_error(HTTPStatus.BAD_REQUEST)
            return None

        if url_path == "/":
            url_path = "/index.html"
        parts = url_path.removeprefix("/").split("/")
        if any(not part or part.startswith(".") or "\\" in part or "\x00" in part for part in parts):
            self.send_error(HTTPStatus.NOT_FOUND)
            return None

        relative_path = Path(*parts)
        is_page = len(parts) == 1 and relative_path.suffix.lower() == ".html"
        is_root_file = len(parts) == 1 and parts[0] in ROOT_FILES
        is_asset = len(parts) > 1 and parts[0] == "assets" and relative_path.suffix.lower() in ASSET_EXTENSIONS
        if not (is_page or is_root_file or is_asset):
            self.send_error(HTTPStatus.NOT_FOUND)
            return None

        root = Path(self.directory).resolve()
        # Keep the standard library's path translation, then reject escaping symlinks.
        target = Path(self.translate_path(url_path)).resolve()
        if not target.is_relative_to(root) or not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return None

        compressed = Path(str(target) + ".gz")
        use_gzip = (
            accepts_gzip(self.headers.get("Accept-Encoding", ""))
            and compressed.is_file()
            and compressed.resolve().is_relative_to(root)
        )
        selected = compressed if use_gzip else target
        try:
            stream = selected.open("rb")
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return None

        stat = selected.stat()
        self.send_response(HTTPStatus.OK)
        content_type = CONTENT_TYPES.get(target.suffix.lower()) or mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(stat.st_size))
        self.send_header("Last-Modified", self.date_time_string(stat.st_mtime))
        self.send_header("Vary", "Accept-Encoding")
        self.send_header("X-Content-Type-Options", "nosniff")
        if use_gzip:
            self.send_header("Content-Encoding", "gzip")
        cache_control = "public, max-age=31536000, immutable" if is_asset and FINGERPRINT.search(target.name) else "no-cache"
        self.send_header("Cache-Control", cache_control)
        self.end_headers()
        return stream


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="127.0.0.1", help="Address to listen on (default: 127.0.0.1)")
    parser.add_argument("--port", default=8000, type=int, help="Port (default: 8000)")
    parser.add_argument("--root", "--directory", dest="directory", type=Path, default=Path(__file__).resolve().parents[1], help="Site root (defaults to the parent of scripts)")
    args = parser.parse_args()
    root = args.directory.resolve()
    if not root.is_dir():
        parser.error(f"Site root is not a directory: {root}")
    handler = functools.partial(SiteHandler, directory=str(root))
    with ThreadingHTTPServer((args.bind, args.port), handler) as server:
        print(f"Serving {root} at http://{args.bind}:{server.server_port}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
